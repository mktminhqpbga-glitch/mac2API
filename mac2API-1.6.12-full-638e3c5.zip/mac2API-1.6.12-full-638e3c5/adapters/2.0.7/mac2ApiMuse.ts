export default {
    id: "mac2ApiMuse",
    label: "mac2API · Muse",
    version: "2.0.7",
    readme: "Tạo ảnh và video qua tài khoản Muse đã cấu hình trong mac2API. Độ phân giải, tỷ lệ và thời lượng là thông số yêu cầu gửi tới Muse. Kết quả thực tế phụ thuộc vào Muse. Nhập Base URL đang dùng và API Key của mac2API.",
    rules: [
        {
            type: "input",
            field: "baseUrl",
            title: "Base URL mac2API",
            value: "https://mac2api.onrender.com/v1",
            validate: [
                {
                    required: true,
                    message: "Hãy nhập Base URL mac2API."
                }
            ]
        },
        {
            type: "input",
            field: "apiKey",
            title: "API Key mac2API",
            value: "",
            props: {
                type: "password",
                showPassword: true,
                autocomplete: "off"
            }
        }
    ],
    models: [
        {
            id: "muse/image",
            label: "Muse Ảnh",
            type: "image",
            mode: [
                "text",
                "singleImage",
                "multiReference"
            ],
            imageSizes: [
                "740",
                "1080",
                "1K",
                "2K",
                "4K"
            ],
            imageRatios: [
                "1:1",
                "9:16",
                "16:9",
                "3:4",
                "4:3"
            ]
        },
        {
            id: "muse/video",
            label: "Muse Video",
            type: "video",
            mode: [
                "text",
                "singleImage"
            ],
            audio: false,
            imageRatios: [
                "1:1",
                "9:16",
                "16:9",
                "3:4",
                "4:3"
            ],
            durationResolutionMap: [
                {
                    duration: [
                        5,
                        10,
                        15,
                        20,
                        30,
                        45,
                        60
                    ],
                    resolution: [
                        "740",
                        "1080",
                        "1K",
                        "2K",
                        "4K"
                    ]
                }
            ],
            rules: [
                {
                    type: "select",
                    field: "mac2ApiVideoRatio",
                    title: "Khung hình Muse",
                    value: "",
                    options: [
                        {
                            label: "Theo tỷ lệ chung",
                            value: ""
                        },
                        {
                            label: "1:1",
                            value: "1:1"
                        },
                        {
                            label: "9:16",
                            value: "9:16"
                        },
                        {
                            label: "16:9",
                            value: "16:9"
                        },
                        {
                            label: "3:4",
                            value: "3:4"
                        },
                        {
                            label: "4:3",
                            value: "4:3"
                        }
                    ]
                }
            ]
        }
    ],
    async generateImage (input) {
        checkPrompt(input);
        if (input.model !== "muse/image") {
            throw new Error("Mô-đun ảnh không hợp lệ.");
        }
        if (input.mask || input.n != null && input.n !== 1 || input.outputFormat) {
            throw new Error("Mô-đun chỉ trả một ảnh và chưa hỗ trợ mặt nạ hoặc định dạng đầu ra tùy chọn.");
        }
        return submit(this, "image", {
            model: input.model,
            prompt: input.prompt,
            ...input.images?.length ? {
                images: input.images.map(imageInput)
            } : {},
            ...imageOptions(input)
        });
    },
    async generateVideo (input) {
        checkPrompt(input, [
            "mac2ApiVideoRatio"
        ]);
        if (input.model !== "muse/video" || input.mode && ![
            "text",
            "singleImage"
        ].includes(String(input.mode))) {
            throw new Error("Chỉ hỗ trợ Muse Video từ văn bản hoặc một ảnh mở đầu.");
        }
        if (input.lastFrame) throw new Error("Muse Video chưa hỗ trợ ảnh khung cuối.");
        if (input.videos?.length || input.audios?.length) {
            throw new Error("Muse Video chưa hỗ trợ âm thanh hoặc video làm tệp tham chiếu.");
        }
        if (input.generateAudio === true) throw new Error("Muse Video chưa hỗ trợ bật tùy chọn Tạo âm thanh.");
        if (input.watermark === true) throw new Error("Muse Video chưa hỗ trợ bật tùy chọn Hình mờ.");
        const images = input.images ?? [];
        if (images.length > 1 || input.firstFrame && images.length) {
            throw new Error("Chỉ gửi một ảnh mở đầu.");
        }
        const first = input.firstFrame ?? images[0];
        if (input.mode === "singleImage" && !first) throw new Error("Hãy thêm ảnh mở đầu.");
        if (input.mode === "text" && first) throw new Error("Hãy chọn chế độ có ảnh mở đầu.");
        return submit(this, "video", {
            model: input.model,
            prompt: input.prompt,
            ...first ? {
                image: imageInput(first)
            } : {},
            ...videoOptions(input)
        });
    },
    async resumeTask (data) {
        if (!data || !validId(data.id) || data.kind !== "image" && data.kind !== "video" || typeof data.base !== "string") {
            throw new Error("Thông tin tác vụ mac2API đã lưu không hợp lệ.");
        }
        return poll(this, {
            id: data.id,
            kind: data.kind,
            base: data.base
        }, taskSignal(this));
    }
};
function connection(context) {
    const entered = context.config.baseUrl?.trim();
    const key = context.config.apiKey?.trim();
    if (!entered || !key) throw new Error("Hãy nhập Base URL và API Key của mac2API.");
    let url;
    try {
        url = new URL(entered);
    } catch  {
        throw new Error("Địa chỉ mac2API không hợp lệ.");
    }
    if (![
        "https:",
        "http:"
    ].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
        throw new Error("Base URL phải là địa chỉ HTTP(S) của mac2API và không chứa khóa hoặc tham số.");
    }
    const root = url.href.replace(/\/+$/, "");
    return {
        base: root.endsWith("/v1") ? root : root + "/v1",
        key
    };
}
async function request(context, endpoint, signal, body) {
    const { base, key } = connection(context);
    const response = await context.tool.fetch(base + endpoint, {
        method: body ? "POST" : "GET",
        headers: {
            Authorization: "Bearer " + key,
            ...body ? {
                "Content-Type": "application/json"
            } : {}
        },
        body: body ? JSON.stringify(body) : undefined,
        redirect: "error",
        signal
    });
    if (!response.ok) {
        if (response.status === 401) throw new Error("API Key mac2API không hợp lệ (HTTP 401).");
        if (response.status === 503) throw new Error("Dịch vụ hoặc phiên trình duyệt mac2API hiện chưa sẵn sàng (HTTP 503).");
        if (response.status === 404) throw new Error("Không tìm thấy endpoint hoặc tác vụ mac2API (HTTP 404).");
        throw new Error("Yêu cầu mac2API thất bại (HTTP " + response.status + ").");
    }
    const result = await response.json();
    if (!result || typeof result !== "object" || Array.isArray(result)) throw new Error("Phản hồi mac2API không hợp lệ.");
    return result;
}
function wait(signal) {
    return new Promise((resolve, reject)=>{
        signal.throwIfAborted();
        const abort = ()=>{
            clearTimeout(timer);
            reject(signal.reason);
        };
        const timer = setTimeout(()=>{
            signal.removeEventListener("abort", abort);
            resolve();
        }, 2000);
        signal.addEventListener("abort", abort, {
            once: true
        });
    });
}
function validId(value) {
    return typeof value === "string" && /^[A-Za-z0-9_-]{1,128}$/.test(value);
}
function taskErrorDetail(context, value) {
    if (typeof value !== "string" || !value.trim()) return "";
    const key = context.config.apiKey?.trim();
    const upload = value.match(/参考素材上传未确认\s*[（(]\s*(\d+)\s*\/\s*(\d+)\s*[）)]/);
    if (upload) return `Muse chưa xác nhận tệp tham chiếu (${upload[1]}/${upload[2]}). Yêu cầu tạo nội dung chưa được gửi.`;
    if (/页面加载超时[（(]未出现聊天输入框[）)]/.test(value)) {
        return "Hết thời gian tải Muse.ai vì ô chat chưa xuất hiện. Tác vụ dừng trước khi gửi yêu cầu. " + "Hãy kiểm tra mạng hoặc proxy của máy chạy mac2API. Chưa xác định phiên đăng nhập hết hiệu lực.";
    }
    const detail = key ? value.split(key).join("[đã ẩn]") : value;
    return detail.replace(/^模型未生成媒体[，,]\s*仅返回文本\s*[:：]\s*/, "Muse chỉ trả văn bản và chưa gửi tệp kết quả. Phản hồi của Muse: ").replace(/\bBearer\s+\S+/gi, "Bearer [đã ẩn]").replace(/\bm2a_[\w-]+/gi, "[đã ẩn]").replace(/\b(?:https?|socks5h?):\/\/[^\s<>"']+/gi, "[đã ẩn URL]").replace(/data:[^\s<>"']+/gi, "[đã ẩn dữ liệu]").replace(/\s+/g, " ").trim().slice(0, 400);
}
async function poll(context, task, signal) {
    if (connection(context).base !== task.base) throw new Error("Base URL đã đổi. Hãy khôi phục địa chỉ của tác vụ gốc.");
    const endpoint = task.kind === "image" ? "/images/tasks/" : "/videos/";
    while(true){
        signal.throwIfAborted();
        const result = await request(context, endpoint + task.id, signal);
        if (result.status === "failed" || result.status === "cancelled" || result.status === "expired") {
            const state = result.status === "failed" ? "thất bại" : result.status === "cancelled" ? "bị hủy" : "hết hạn";
            const raw = typeof result.error === "string" && result.error.trim() ? result.error : result.last_error;
            const reason = taskErrorDetail(context, raw);
            throw Object.assign(new Error(`Tác vụ mac2API ${task.id} ${state}.${reason ? " Lý do: " + reason : " Xem chi tiết trong mục Tác vụ của mac2API."}`), {
                code: "MEDIA_TASK_FAILED"
            });
        }
        if (result.status === "completed") {
            const candidate = Array.isArray(result.data) ? result.data[0]?.url : result.url;
            if (typeof candidate !== "string") throw new Error("Tác vụ hoàn tất nhưng không có đường dẫn đến tệp.");
            const url = new URL(candidate, task.base);
            if (url.origin !== new URL(task.base).origin || url.username || url.password || !url.pathname.includes("/v1/media/")) {
                throw new Error("Đường dẫn tệp nằm ngoài địa chỉ media mac2API đã cấu hình.");
            }
            return [
                {
                    mediaType: task.kind,
                    type: "url",
                    url: url.href
                }
            ];
        }
        if (result.status !== "queued" && result.status !== "processing") {
            throw new Error("Trạng thái tác vụ chưa rõ. Hãy kiểm tra tác vụ cũ trước khi gửi lại.");
        }
        await wait(signal);
    }
}
function taskSignal(context) {
    const timeout = AbortSignal.timeout(15 * 60 * 1000);
    return context.signal ? AbortSignal.any([
        timeout,
        context.signal
    ]) : timeout;
}
async function submit(context, kind, body) {
    const signal = taskSignal(context);
    signal.throwIfAborted();
    const { base } = connection(context);
    const endpoint = kind === "image" ? "/images/tasks" : "/videos";
    let result;
    try {
        result = await request(context, endpoint, signal, body);
    } catch (error) {
        if (signal.aborted) throw error;
        throw new Error((error instanceof Error ? error.message : "Không kết nối được với mac2API.") + " Kiểm tra mục Tác vụ trước khi gửi lại.");
    }
    const id = result.task_id ?? result.id;
    if (!validId(id)) throw new Error("Chưa xác nhận được mã tác vụ. Kiểm tra bảng quản trị trước khi gửi lại.");
    const task = {
        id,
        kind,
        base
    };
    await context.saveTaskData?.(task);
    return poll(context, task, signal);
}
function checkPrompt(request, allowedOptions = []) {
    if (!request.prompt?.trim()) throw new Error("Hãy nhập mô tả.");
    if (Object.keys(request.other ?? {}).some((key)=>!allowedOptions.includes(key))) throw new Error("Mô-đun này chưa hỗ trợ tham số tùy chỉnh.");
}
function imageInput(input) {
    if (input.type === "url") {
        const url = new URL(input.url);
        if (![
            "http:",
            "https:"
        ].includes(url.protocol) || url.username || url.password) {
            throw new Error("Ảnh tham chiếu phải là URL HTTP(S) hoặc tệp ảnh.");
        }
        return url.href;
    }
    if (!input.mimeType.startsWith("image/")) throw new Error("Tệp tham chiếu phải là ảnh.");
    const data = input.type === "base64" ? input.data : Buffer.from(input.data).toString("base64");
    return "data:" + input.mimeType + ";base64," + data;
}
function requestedRatio(value) {
    if (value === undefined || value === null || value === "") return;
    if (typeof value !== "string") throw new Error("Tỷ lệ khung hình không hợp lệ.");
    const ratio = value.trim();
    if (!ratio || ratio.toLowerCase() === "auto") return;
    if (![
        "1:1",
        "9:16",
        "16:9",
        "3:4",
        "4:3"
    ].includes(ratio)) {
        throw new Error("Hãy chọn tỷ lệ 1:1, 9:16, 16:9, 3:4 hoặc 4:3.");
    }
    return ratio;
}
function resolutionPreset(value) {
    const choice = value?.trim().toUpperCase() ?? "";
    const pixels = choice.match(/^(740|1080)P?$/);
    if (pixels) return pixels[1] + "p";
    if ([
        "1K",
        "2K",
        "4K"
    ].includes(choice)) return choice;
    return undefined;
}
function imageOptions(input) {
    const ratio = requestedRatio(input.ratio);
    const size = input.size?.trim();
    const quality = input.quality?.trim().toLowerCase();
    const preferred = resolutionPreset(size) || resolutionPreset(quality);
    const explicitSize = size && ![
        "auto",
        "default"
    ].includes(size.toLowerCase()) ? size : undefined;
    if (explicitSize && !resolutionPreset(explicitSize) && !/^\d{2,5}x\d{2,5}$/i.test(explicitSize)) {
        throw new Error("Hãy chọn mức ảnh 740, 1080, 1K, 2K hoặc 4K.");
    }
    if (quality && !resolutionPreset(quality) && ![
        "auto",
        "default",
        "standard",
        "low",
        "medium",
        "high",
        "hd"
    ].includes(quality)) {
        throw new Error("Mức chất lượng ảnh không hợp lệ.");
    }
    const outputSize = preferred || explicitSize;
    const extra = outputSize ? "Độ phân giải ảnh mong muốn: " + outputSize + "." : quality && [
        "low",
        "medium",
        "high",
        "hd"
    ].includes(quality) ? "Chất lượng ảnh mong muốn: " + quality + "." : "";
    return {
        ...ratio ? {
            aspect_ratio: ratio
        } : {},
        ...outputSize ? {
            size: outputSize
        } : {},
        ...extra ? {
            extra
        } : {}
    };
}
function videoOptions(input) {
    const ratio = requestedRatio(input.other?.mac2ApiVideoRatio) ?? requestedRatio(input.ratio);
    const requestedResolution = input.resolution?.trim();
    const resolution = resolutionPreset(requestedResolution) || (requestedResolution?.toLowerCase() === "720p" ? "720p" : undefined);
    if (requestedResolution && !resolution && ![
        "auto",
        "default"
    ].includes(requestedResolution.toLowerCase())) {
        throw new Error("Hãy chọn mức video 740, 1080, 1K, 2K hoặc 4K.");
    }
    const duration = input.duration;
    if (duration !== undefined && ![
        5,
        10,
        15,
        20,
        30,
        45,
        60
    ].includes(duration)) {
        throw new Error("Hãy chọn thời lượng 5, 10, 15, 20, 30, 45 hoặc 60 giây.");
    }
    const defaultRatioHint = ratio !== "9:16" || !resolution || resolution === "720p";
    return {
        ...ratio && defaultRatioHint ? {
            aspect_ratio: ratio
        } : {},
        ...duration !== undefined ? {
            duration
        } : {},
        ...resolution ? {
            resolution
        } : {},
        ...ratio ? {
            extra: "Tỷ lệ khung hình video mong muốn: " + ratio + "."
        } : {}
    };
}
