export default {
    id: "mac2ApiChatGpt",
    label: "mac2API · ChatGPT Web",
    version: "2.0.7",
    readme: "Tạo ảnh từ văn bản qua ChatGPT Web. mac2API cần chạy cùng Chrome đã đăng nhập. Độ phân giải và tỷ lệ là thông số yêu cầu gửi tới mô hình. Kết quả thực tế phụ thuộc vào mô hình. Nhập Base URL đang dùng và API Key của mac2API.",
    rules: [
        {
            type: "input",
            field: "baseUrl",
            title: "Base URL mac2API",
            value: "http://127.0.0.1:18610/v1",
            validate: [
                {
                    required: true,
                    message: "Hãy nhập Base URL mac2API."
                }
            ]
        },
        {
            type: "input",
            field: "apiKey",
            title: "API Key mac2API",
            value: "",
            props: {
                type: "password",
                showPassword: true,
                autocomplete: "off"
            }
        }
    ],
    models: [
        {
            id: "chatgpt/image",
            label: "ChatGPT Web Ảnh",
            type: "image",
            mode: [
                "text"
            ],
            imageSizes: [
                "740",
                "1080",
                "1K",
                "2K",
                "4K"
            ],
            imageRatios: [
                "1:1",
                "9:16",
                "16:9",
                "3:4",
                "4:3"
            ]
        }
    ],
    async generateImage (input) {
        checkPrompt(input);
        if (input.model !== "chatgpt/image") {
            throw new Error("Mô-đun ảnh không hợp lệ.");
        }
        if (input.mask || input.n != null && input.n !== 1 || input.outputFormat) {
            throw new Error("Mô-đun chỉ trả một ảnh và chưa hỗ trợ mặt nạ hoặc định dạng đầu ra tùy chọn.");
        }
        if (input.images?.length) {
            throw new Error("ChatGPT Web hiện chỉ tạo ảnh từ mô tả văn bản.");
        }
        return submit(this, "image", {
            model: input.model,
            prompt: input.prompt,
            ...imageOptions(input)
        });
    },
    async resumeTask (data) {
        if (!data || !validId(data.id) || data.kind !== "image" || typeof data.base !== "string") {
            throw new Error("Thông tin tác vụ mac2API đã lưu không hợp lệ.");
        }
        return poll(this, {
            id: data.id,
            kind: data.kind,
            base: data.base
        }, taskSignal(this));
    }
};
function connection(context) {
    const entered = context.config.baseUrl?.trim();
    const key = context.config.apiKey?.trim();
    if (!entered || !key) throw new Error("Hãy nhập Base URL và API Key của mac2API.");
    let url;
    try {
        url = new URL(entered);
    } catch  {
        throw new Error("Địa chỉ mac2API không hợp lệ.");
    }
    if (![
        "https:",
        "http:"
    ].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
        throw new Error("Base URL phải là địa chỉ HTTP(S) của mac2API và không chứa khóa hoặc tham số.");
    }
    const root = url.href.replace(/\/+$/, "");
    return {
        base: root.endsWith("/v1") ? root : root + "/v1",
        key
    };
}
async function request(context, endpoint, signal, body) {
    const { base, key } = connection(context);
    const response = await context.tool.fetch(base + endpoint, {
        method: body ? "POST" : "GET",
        headers: {
            Authorization: "Bearer " + key,
            ...body ? {
                "Content-Type": "application/json"
            } : {}
        },
        body: body ? JSON.stringify(body) : undefined,
        redirect: "error",
        signal
    });
    if (!response.ok) {
        if (response.status === 401) throw new Error("API Key mac2API không hợp lệ (HTTP 401).");
        if (response.status === 503) throw new Error("Dịch vụ hoặc phiên trình duyệt mac2API hiện chưa sẵn sàng (HTTP 503).");
        if (response.status === 404) throw new Error("Không tìm thấy endpoint hoặc tác vụ mac2API (HTTP 404).");
        throw new Error("Yêu cầu mac2API thất bại (HTTP " + response.status + ").");
    }
    const result = await response.json();
    if (!result || typeof result !== "object" || Array.isArray(result)) throw new Error("Phản hồi mac2API không hợp lệ.");
    return result;
}
function wait(signal) {
    return new Promise((resolve, reject)=>{
        signal.throwIfAborted();
        const abort = ()=>{
            clearTimeout(timer);
            reject(signal.reason);
        };
        const timer = setTimeout(()=>{
            signal.removeEventListener("abort", abort);
            resolve();
        }, 2000);
        signal.addEventListener("abort", abort, {
            once: true
        });
    });
}
function validId(value) {
    return typeof value === "string" && /^[A-Za-z0-9_-]{1,128}$/.test(value);
}
function taskErrorDetail(context, value) {
    if (typeof value !== "string" || !value.trim()) return "";
    const key = context.config.apiKey?.trim();
    const upload = value.match(/参考素材上传未确认\s*[（(]\s*(\d+)\s*\/\s*(\d+)\s*[）)]/);
    if (upload) return `Muse chưa xác nhận tệp tham chiếu (${upload[1]}/${upload[2]}). Yêu cầu tạo nội dung chưa được gửi.`;
    const detail = key ? value.split(key).join("[đã ẩn]") : value;
    return detail.replace(/\bBearer\s+\S+/gi, "Bearer [đã ẩn]").replace(/\bm2a_[\w-]+/gi, "[đã ẩn]").replace(/\b(?:https?|socks5h?):\/\/[^\s<>"']+/gi, "[đã ẩn URL]").replace(/data:[^\s<>"']+/gi, "[đã ẩn dữ liệu]").replace(/\s+/g, " ").trim().slice(0, 400);
}
async function poll(context, task, signal) {
    if (connection(context).base !== task.base) throw new Error("Base URL đã đổi. Hãy khôi phục địa chỉ của tác vụ gốc.");
    const endpoint = "/images/tasks/";
    while(true){
        signal.throwIfAborted();
        const result = await request(context, endpoint + task.id, signal);
        if (result.status === "failed" || result.status === "cancelled" || result.status === "expired") {
            const state = result.status === "failed" ? "thất bại" : result.status === "cancelled" ? "bị hủy" : "hết hạn";
            const raw = typeof result.error === "string" && result.error.trim() ? result.error : result.last_error;
            const reason = taskErrorDetail(context, raw);
            throw Object.assign(new Error(`Tác vụ mac2API ${task.id} ${state}.${reason ? " Lý do: " + reason : " Xem chi tiết trong mục Tác vụ của mac2API."}`), {
                code: "MEDIA_TASK_FAILED"
            });
        }
        if (result.status === "completed") {
            const candidate = Array.isArray(result.data) ? result.data[0]?.url : undefined;
            if (typeof candidate !== "string") throw new Error("Tác vụ hoàn tất nhưng không có đường dẫn đến tệp.");
            const url = new URL(candidate, task.base);
            if (url.origin !== new URL(task.base).origin || url.username || url.password || !url.pathname.includes("/v1/media/")) {
                throw new Error("Đường dẫn tệp nằm ngoài địa chỉ media mac2API đã cấu hình.");
            }
            return [
                {
                    mediaType: task.kind,
                    type: "url",
                    url: url.href
                }
            ];
        }
        if (result.status !== "queued" && result.status !== "processing") {
            throw new Error("Trạng thái tác vụ chưa rõ. Hãy kiểm tra tác vụ cũ trước khi gửi lại.");
        }
        await wait(signal);
    }
}
function taskSignal(context) {
    const timeout = AbortSignal.timeout(15 * 60 * 1000);
    return context.signal ? AbortSignal.any([
        timeout,
        context.signal
    ]) : timeout;
}
async function submit(context, kind, body) {
    const signal = taskSignal(context);
    signal.throwIfAborted();
    const { base } = connection(context);
    const endpoint = "/images/tasks";
    const catalog = await request(context, "/models", signal);
    if (!Array.isArray(catalog.data) || !catalog.data.some((item)=>item?.id === body.model)) {
        throw new Error("Máy chủ hiện chưa bật mô-đun ảnh web này. Kiểm tra Base URL và cấu hình Chrome của mac2API.");
    }
    let result;
    try {
        result = await request(context, endpoint, signal, body);
    } catch (error) {
        if (signal.aborted) throw error;
        throw new Error((error instanceof Error ? error.message : "Không kết nối được với mac2API.") + " Kiểm tra mục Tác vụ trước khi gửi lại.");
    }
    const id = result.task_id ?? result.id;
    if (!validId(id)) throw new Error("Chưa xác nhận được mã tác vụ. Kiểm tra bảng quản trị trước khi gửi lại.");
    const task = {
        id,
        kind,
        base
    };
    await context.saveTaskData?.(task);
    return poll(context, task, signal);
}
function checkPrompt(request) {
    if (!request.prompt?.trim()) throw new Error("Hãy nhập mô tả.");
    if (Object.keys(request.other ?? {}).length) throw new Error("Mô-đun này chưa hỗ trợ tham số tùy chỉnh.");
}
function requestedRatio(value) {
    if (value === undefined || value === null || value === "") return;
    if (typeof value !== "string") throw new Error("Tỷ lệ khung hình không hợp lệ.");
    const ratio = value.trim();
    if (!ratio || ratio.toLowerCase() === "auto") return;
    if (![
        "1:1",
        "9:16",
        "16:9",
        "3:4",
        "4:3"
    ].includes(ratio)) {
        throw new Error("Hãy chọn tỷ lệ 1:1, 9:16, 16:9, 3:4 hoặc 4:3.");
    }
    return ratio;
}
function resolutionPreset(value) {
    const choice = value?.trim().toUpperCase() ?? "";
    const pixels = choice.match(/^(740|1080)P?$/);
    if (pixels) return pixels[1] + "p";
    if ([
        "1K",
        "2K",
        "4K"
    ].includes(choice)) return choice;
    return undefined;
}
function imageOptions(input) {
    const ratio = requestedRatio(input.ratio);
    const size = input.size?.trim();
    const quality = input.quality?.trim().toLowerCase();
    const preferred = resolutionPreset(size) || resolutionPreset(quality);
    const explicitSize = size && ![
        "auto",
        "default"
    ].includes(size.toLowerCase()) ? size : undefined;
    if (explicitSize && !resolutionPreset(explicitSize) && !/^\d{2,5}x\d{2,5}$/i.test(explicitSize)) {
        throw new Error("Hãy chọn mức ảnh 740, 1080, 1K, 2K hoặc 4K.");
    }
    if (quality && !resolutionPreset(quality) && ![
        "auto",
        "default",
        "standard",
        "low",
        "medium",
        "high",
        "hd"
    ].includes(quality)) {
        throw new Error("Mức chất lượng ảnh không hợp lệ.");
    }
    const outputSize = preferred || explicitSize;
    const extra = outputSize ? "Độ phân giải ảnh mong muốn: " + outputSize + "." : quality && [
        "low",
        "medium",
        "high",
        "hd"
    ].includes(quality) ? "Chất lượng ảnh mong muốn: " + quality + "." : "";
    return {
        ...ratio ? {
            aspect_ratio: ratio
        } : {},
        ...outputSize ? {
            size: outputSize
        } : {},
        ...extra ? {
            extra
        } : {}
    };
}
