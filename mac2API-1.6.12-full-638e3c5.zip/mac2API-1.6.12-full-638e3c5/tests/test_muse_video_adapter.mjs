import assert from 'node:assert/strict';
import { test } from 'node:test';

const base = 'http://127.0.0.1:18610';
const request = {
  model: 'muse/video', prompt: 'Tạo video meme của một con chó', mode: 'text',
  ratio: '1:1', resolution: '720p', duration: 14, images: [], videos: [], audios: [],
};
const frame = { type: 'url', url: 'https://example.invalid/frame.png' };

function fixture() {
  const calls = [];
  const saved = [];
  const context = {
    config: { baseUrl: base, apiKey: 'fixture-key' },
    tool: { fetch: async (url, options) => {
      calls.push({ url, method: options.method, body: options.body && JSON.parse(options.body) });
      return options.method === 'POST'
        ? Response.json({ id: 'task_fixture', status: 'queued' })
        : Response.json({ status: 'completed', url: '/v1/media/fixture.mp4' });
    } },
    saveTaskData: async (data) => { saved.push(data); },
  };
  return { context, calls, saved };
}

for (const name of ['mac2ApiMuse', 'mac2Api']) {
  test(`${name} translates old Muse composer timeouts`, {
    skip: !process.features.typescript && 'Node TypeScript stripping is required',
  }, async () => {
    const { default: adapter } = await import(`../adapters/${name}.ts`);
    const { context } = fixture();
    context.tool.fetch = async (_url, options) => {
      assert.equal(options.method, 'GET');
      return Response.json({ status: 'failed', error: 'muse.ai 页面加载超时（未出现聊天输入框），请检查服务器网络后重试；未确认会话失效' });
    };
    await assert.rejects(adapter.resumeTask.call(context, { id: 'task_fixture', kind: 'video', base: `${base}/v1` }), (error) => {
      assert.equal(error.code, 'MEDIA_TASK_FAILED');
      assert.match(error.message, /task_fixture.*Hết thời gian tải Muse.ai.*Chưa xác định phiên đăng nhập hết hiệu lực/);
      assert.doesNotMatch(error.message, /页面加载超时/);
      return true;
    });
  });

  test(`${name} translates the saved text-only media error and preserves the reply`, {
    skip: !process.features.typescript && 'Node TypeScript stripping is required',
  }, async () => {
    const { default: adapter } = await import(`../adapters/${name}.ts`);
    const { context } = fixture();
    context.tool.fetch = async (_url, options) => {
      assert.equal(options.method, 'GET');
      return Response.json({
        status: 'failed', error: '模型未生成媒体，仅返回文本: Phương án tạo ảnh, bạn duyệt giúp mình nhé',
      });
    };
    await assert.rejects(adapter.resumeTask.call(context, { id: 'task_fixture', kind: 'image', base: `${base}/v1` }), (error) => {
      assert.equal(error.code, 'MEDIA_TASK_FAILED');
      assert.match(error.message, /task_fixture.*Muse chỉ trả văn bản.*Phương án tạo ảnh/);
      assert.doesNotMatch(error.message, /模型未生成媒体/);
      return true;
    });
  });
}

for (const name of ['mac2ApiMuse', 'mac2Api']) {
  test(`${name} accepts default-off switches and creates a Muse video task`, {
    skip: !process.features.typescript && 'Node TypeScript stripping is required',
  }, async () => {
    const { default: adapter } = await import(`../adapters/${name}.ts`);
    const { context, calls, saved } = fixture();
    const assets = await adapter.generateVideo.call(context, { ...request, generateAudio: false, watermark: false });
    assert.deepEqual(calls, [
      { url: `${base}/v1/videos`, method: 'POST', body: {
        model: 'muse/video', prompt: request.prompt, aspect_ratio: '1:1', duration: 14, resolution: '720p',
      } },
      { url: `${base}/v1/videos/task_fixture`, method: 'GET', body: undefined },
    ]);
    assert.deepEqual(saved, [{ id: 'task_fixture', kind: 'video', base: `${base}/v1` }]);
    assert.deepEqual(assets, [{ mediaType: 'video', type: 'url', url: `${base}/v1/media/fixture.mp4` }]);

    await adapter.generateVideo.call(context, { ...request, mode: 'singleImage', firstFrame: frame, generateAudio: false });
    assert.equal(calls[2].body.image, frame.url);
  });

  test(`${name} reports which unsupported setting is enabled before submitting`, {
    skip: !process.features.typescript && 'Node TypeScript stripping is required',
  }, async () => {
    const { default: adapter } = await import(`../adapters/${name}.ts`);
    const { context, calls } = fixture();
    for (const [input, error] of [
      [{ lastFrame: frame }, /ảnh khung cuối/],
      [{ videos: [frame] }, /âm thanh hoặc video làm tệp tham chiếu/],
      [{ audios: [frame] }, /âm thanh hoặc video làm tệp tham chiếu/],
      [{ generateAudio: true }, /bật tùy chọn Tạo âm thanh/],
      [{ watermark: true }, /bật tùy chọn Hình mờ/],
    ]) {
      await assert.rejects(adapter.generateVideo.call(context, { ...request, ...input }), error);
    }
    assert.deepEqual(calls, []);
  });
}
