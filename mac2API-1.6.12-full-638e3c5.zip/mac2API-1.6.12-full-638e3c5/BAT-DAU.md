# Bắt đầu với mac2API trên Mac

Gói gồm mac2API 1.6.12 từ commit `638e3c5`, tiện ích Chrome/Edge 1.0.5 và ba adapter media 2.0.7.

## Khởi động bảng quản trị

1. Giải nén toàn bộ ZIP. Giữ `admin.html` và `start-mac2api.command` cạnh `app.py`.
2. Nếu bản cũ đang chạy, chờ tác vụ hoàn tất rồi dừng bản đó.
3. Nếu giải nén vào Downloads, mở Terminal và chạy các lệnh dưới đây.

```bash
cd ~/Downloads/mac2API-1.6.12-full-638e3c5
python3 -m venv venv
venv/bin/python -m pip install -r requirements.txt
bash start-mac2api.command
```

Mở địa chỉ Terminal in ra, mặc định là [http://127.0.0.1:18610/admin](http://127.0.0.1:18610/admin). Nếu Terminal báo cổng `18610` đang được sử dụng, kiểm tra tiến trình đang nghe bằng `lsof -nP -iTCP:18610 -sTCP:LISTEN`. Nếu đó là bản mac2API cũ, dừng nó ở nơi đã khởi động rồi chạy lại `bash start-mac2api.command`.

## Dùng lại cấu hình và dữ liệu

Sau khi đã cài thư viện, thay lệnh khởi động cuối bằng lệnh sau. Điền đường dẫn tới thư mục chứa `.env` và `data/` của bản đang dùng.

```bash
MUSE2API_HOME="/duong/dan/ban-cu" bash start-mac2api.command
```

Bản mới đọc giao diện từ gói đã giải nén và dùng dữ liệu trong thư mục cũ.

## Tiện ích và adapter

- Nạp tiện ích Chrome/Edge từ `extension/`.
- Trong MacFlow hoặc Toonflow, dùng **Nhập tệp → Chọn tệp** với các tệp trong `adapters/2.0.7/`. Muse có ảnh và video. ChatGPT Web và Gemini Web có ảnh.
- Các adapter nằm ngay trong `adapters/` là bản tương thích đi kèm mã nguồn.

Xem các tùy chọn kết nối trong [README.md](README.md).
