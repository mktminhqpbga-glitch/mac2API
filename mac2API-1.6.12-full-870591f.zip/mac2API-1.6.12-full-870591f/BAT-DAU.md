# Bắt đầu với mac2API trên Mac

Gói này gồm máy chủ mac2API 1.6.12 ở commit `870591f`, tiện ích Chrome và Edge 1.0.5, cùng ba adapter media 2.0.7 cho MacFlow và Toonflow.

## Giải nén cả thư mục

- Giữ `app.py`, `admin.html`, `requirements.txt` và các mô-đun Python ở cùng cấp. Máy chủ đọc giao diện từ thư mục chứa `app.py`.
- Thư mục `extension/` là tiện ích nạp từ Chrome hoặc Edge.
- Thư mục `adapters/2.0.7/` có ba tệp `mac2ApiMuse.ts`, `mac2ApiChatGpt.ts` và `mac2ApiGemini.ts`. Trong MacFlow, dùng **Nhập tệp → Chọn tệp** với từng tệp này. Nếu đã cài adapter cùng tên, dùng mục chỉnh sửa adapter hiện có để cập nhật mã.
- Các adapter ở ngay trong `adapters/` là các phiên bản theo commit máy chủ, dùng cho thiết lập đã nhập chúng.

## Chạy trên Mac

Sau khi giải nén vào Downloads, mở Terminal và chạy từ thư mục mới. Nếu bản cũ đang dùng cổng `18610`, chờ các tác vụ hiện tại kết thúc rồi dừng tiến trình cũ trước khi chạy lệnh.

```bash
cd ~/Downloads/mac2API-1.6.12-full-870591f
python3 -m venv venv
venv/bin/python -m pip install -r requirements.txt
venv/bin/python -m uvicorn app:app --host 127.0.0.1 --port 18610
```

Mở [Bảng quản trị mac2API](http://127.0.0.1:18610/admin).

Để dùng lại cấu hình và dữ liệu cũ, chạy lệnh khởi động dưới đây từ thư mục mới. Thay đường dẫn mẫu bằng thư mục gốc chứa `.env` và `data/` của bản đang dùng. Lệnh này lấy mã và giao diện từ gói mới, đồng thời đọc cấu hình và lưu dữ liệu ở thư mục cũ.

```bash
MUSE2API_HOME="/duong/dan/thu-muc-mac2API-cu" venv/bin/python -m uvicorn app:app --host 127.0.0.1 --port 18610
```

Thiết lập Chrome và các tùy chọn API nằm trong [README.md](README.md).
